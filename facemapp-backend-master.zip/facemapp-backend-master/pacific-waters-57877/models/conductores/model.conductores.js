var db = require ('../../sqldb');
//console.log('entro ruta');

var UserTable = db.mongoose.Schema({
    tipoDocumento:String,
    documento:String,
    nombres: String,
    apellidos: String,
    fecha_nacimiento: String,
    fecha_inscripcion: String,
    estado:String
});
var Conductor = db.mongoose.model('conductor', UserTable,'conductor');

//var Ruta = db.Mongoose.model('palmira', RutaTable);

//console.log('fin');

module.exports = Conductor;
