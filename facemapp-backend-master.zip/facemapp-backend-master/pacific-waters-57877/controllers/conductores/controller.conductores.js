var db = require('../../sqldb.js');
var Conductor = require('../../models/conductores/model.conductores');


module.exports.index = function (req, res) {
    Conductor.find(function (err, conductor) {
        if (err) {
        // Note that this error doesn't mean nothing was found,
        // it means the database had an error while searching, hence the 500 status
            res.status(500).send(err)
        } 
        console.log(conductor);
         
        res.send(conductor);
    });

}

module.exports.show = function (req, res) {
    console.log('conductor buscado');
    console.log(req.params.idDocumento)
    console.log(req.params.tipo)
    Conductor.find({tipoDocumento:req.params.tipo,documento:req.params.idDocumento},function (err, conductor) {
        if (err) {
        // Note that this error doesn't mean nothing was found,
        // it means the database had an error while searching, hence the 500 status
            res.status(500).send(err)
        } 

        console.log(conductor);
         
        res.send(conductor);
    });
}

module.exports.create = function (req, res) {
    console.log("Conductor");
    console.log(req.body);
    var conductor = new Conductor(req.body);
    conductor.save(function (err) {
        if (err) {
            res.json({
                success: true,
                message: 'Error al Registar conductor'
            });
        }
        res.json({
            success: true,
            message: 'Conductor Registrado con Exito'
        });
    })

}

module.exports.update = function (req, res) {
    console.log('Conductor');
    console.log(req.body);
    console.log(req.params);
    var query = { tipoDocumento: req.params.tipo, documento: req.params.idDocumento };

    Conductor.findOneAndUpdate(query, { $set: { 
        tipoDocumento: req.body.tipoDocumento,
        nombres: req.body.nombres,
        apellidos: req.body.apellidos,
        fecha_nacimiento: req.body.fecha_nacimiento,
        fecha_inscripcion: req.body.fecha_inscripcion,
        estado: req.body.estado }
        }, function(err,conductorActualizado){

        if (err) {
            // Note that this error doesn't mean nothing was found,
            // it means the database had an error while searching, hence the 500 status
                res.status(500).send(err)
            }

            console.log('Actualizando....');
            console.log(conductorActualizado);
            //res.status(202);
            res.json({
                success: true,
                message: 'Conductor Actualizado'
            });

    })
}




